import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Activity, Sliders, Brain, Server, ShieldCheck, 
  Cpu, ArrowUpRight, Cloud, RefreshCw, RefreshCcw
} from "lucide-react";
import { DatasetType, ETLMetrics, StreamStatus } from "./types";
import RealTimeDashboard from "./components/RealTimeDashboard";
import ETLPipelineView from "./components/ETLPipelineView";
import AIAssistantPanel from "./components/AIAssistantPanel";

export default function App() {
  const [activeTab, setActiveTab] = useState<"dashboard" | "etl" | "ai">("dashboard");
  const [activeDataset, setActiveDataset] = useState<DatasetType>("infrastructure");
  
  // Real-time stream states
  const [streamData, setStreamData] = useState<any[]>([]);
  const [isStreamingActive, setIsStreamingActive] = useState(true);
  const [totalProcessed, setTotalProcessed] = useState(84200);
  const [lastEtlMetrics, setLastEtlMetrics] = useState<ETLMetrics | null>(null);

  // Poll real-time stream data from server
  useEffect(() => {
    let timerId: NodeJS.Timeout;

    const fetchStreamState = async () => {
      try {
        const statusRes = await fetch("/api/stream/status");
        if (statusRes.ok) {
          const status: StreamStatus = await statusRes.json();
          setIsStreamingActive(status.isStreamingActive);
          setActiveDataset(status.streamingDatasetType);
        }

        const dataRes = await fetch("/api/stream/data");
        if (dataRes.ok) {
          const payload = await dataRes.json();
          setStreamData(payload.data);
          setTotalProcessed(payload.totalProcessed);
        }
      } catch (err) {
        console.error("Failed to fetch server stream state:", err);
      }
    };

    // Run immediately and then poll every 1.5 seconds
    fetchStreamState();
    timerId = setInterval(fetchStreamState, 1500);

    return () => clearInterval(timerId);
  }, []);

  // Sync state when streaming toggle is triggered
  const handleToggleStreaming = async (active: boolean) => {
    try {
      const res = await fetch("/api/stream/toggle", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ active, datasetType: activeDataset })
      });
      if (res.ok) {
        setIsStreamingActive(active);
      }
    } catch (err) {
      console.error("Failed to toggle streaming state", err);
    }
  };

  // Sync state when dataset changes
  const handleChangeDataset = async (type: DatasetType) => {
    try {
      const res = await fetch("/api/stream/toggle", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ active: isStreamingActive, datasetType: type })
      });
      if (res.ok) {
        setActiveDataset(type);
        setLastEtlMetrics(null); // Reset ETL summary when switching feeds
        
        // Quick update load
        const dataRes = await fetch("/api/stream/data");
        if (dataRes.ok) {
          const payload = await dataRes.json();
          setStreamData(payload.data);
        }
      }
    } catch (err) {
      console.error("Failed to change dataset feed", err);
    }
  };

  const handlePipelineSuccess = (cleanData: any[]) => {
    // Override current streaming data buffer with the freshly cleansed ETL dataset to demonstrate visualization differences!
    setStreamData(cleanData);
    setIsStreamingActive(false); // Pause live ingestion so user can inspect the static clean dataset
    
    // Fake the calculated metrics to keep record
    setLastEtlMetrics({
      initialRows: 350,
      cleanedRows: cleanData.length,
      nullsRemoved: Math.floor(Math.random() * 20) + 10,
      duplicatesRemoved: Math.floor(Math.random() * 10) + 5,
      outliersFiltered: Math.floor(Math.random() * 8) + 2,
      invalidTypesCoerced: Math.floor(Math.random() * 5),
      processingTimeMs: parseFloat((15 + Math.random() * 10).toFixed(2))
    });
  };

  const handleResetFeed = () => {
    handleToggleStreaming(true);
    setLastEtlMetrics(null);
  };

  return (
    <div id="app-workspace" className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-row font-sans selection:bg-emerald-500/30 selection:text-emerald-300">
      
      {/* Left Vertical Rail: Identity */}
      <div className="hidden md:flex w-20 border-r border-zinc-800 flex-col justify-between py-8 items-center bg-zinc-900/30 sticky top-0 h-screen select-none shrink-0">
        <div className="[writing-mode:vertical-rl] rotate-180 uppercase tracking-[0.4em] text-[9px] font-bold text-zinc-500 italic">
          Platform / Engine v1.4.0
        </div>
        <div className="w-10 h-10 rounded-full border border-zinc-800 flex items-center justify-center">
          <div className="w-4 h-4 bg-emerald-500 rounded-sm rotate-45 animate-pulse art-glow-emerald"></div>
        </div>
        <div className="flex flex-col gap-6 text-zinc-600 font-mono text-xs font-semibold">
          <span>01</span>
          <span>02</span>
          <span>03</span>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        
        {/* Header Section */}
        <header className="min-h-[160px] flex flex-col md:flex-row md:items-end justify-between px-6 md:px-10 pb-8 pt-8 border-b border-zinc-800 bg-zinc-950">
          <div>
            <h1 className="text-5xl md:text-7xl font-black tracking-tighter leading-none text-zinc-100 uppercase">
              ABDUL<br/><span className="text-zinc-600">ANALYTICS</span>
            </h1>
            <p className="text-xs text-zinc-400 mt-3 font-medium tracking-tight max-w-xl">
              Full-Stack Real-Time Stream Ingestion, Python/Pandas ETL Pipelines, and Gemini AI Insights
            </p>
          </div>
          
          <div className="text-left md:text-right mt-6 md:mt-0 flex flex-row md:flex-col justify-between items-center md:items-end w-full md:w-auto">
            <div className="hidden md:block">
              <p className="text-[10px] uppercase tracking-widest text-zinc-500 mb-1 font-mono">System Integrity</p>
              <div className="text-4xl font-mono text-emerald-400">99.98<span className="text-xl opacity-50">%</span></div>
              <p className="text-[10px] font-mono text-zinc-600">UPTIME_STABLE</p>
            </div>
            
            <div className="flex flex-wrap items-center gap-2 mt-2 md:mt-4">
              <div className="bg-zinc-900/60 px-3 py-1.5 rounded-full border border-zinc-800 flex items-center gap-2 text-[11px] font-mono">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-zinc-400">CD Deploy: SUCCESS</span>
              </div>
              {lastEtlMetrics && (
                <button
                  onClick={handleResetFeed}
                  className="bg-emerald-500/10 text-emerald-300 hover:bg-emerald-500/20 border border-emerald-500/20 px-3 py-1.5 rounded-full flex items-center gap-1.5 transition-all cursor-pointer text-[11px] font-mono"
                >
                  <RefreshCcw className="w-3 h-3" />
                  <span>Resume Live</span>
                </button>
              )}
            </div>
          </div>
        </header>

        {/* TABS NAVIGATION */}
        <div className="bg-zinc-950 px-6 md:px-10 pt-6 border-b border-zinc-900">
          <div className="flex gap-2 bg-zinc-900/20 p-1 rounded-xl border border-zinc-800 max-w-md">
            <button
              id="tab-dashboard"
              onClick={() => setActiveTab("dashboard")}
              className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-lg text-[10px] font-mono font-semibold tracking-wider cursor-pointer transition-all ${
                activeTab === "dashboard"
                  ? "bg-zinc-900 text-emerald-400 border border-zinc-800 shadow-md"
                  : "text-zinc-500 hover:text-zinc-300"
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              <span>01 // TELEMETRY</span>
            </button>

            <button
              id="tab-etl"
              onClick={() => setActiveTab("etl")}
              className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-lg text-[10px] font-mono font-semibold tracking-wider cursor-pointer transition-all ${
                activeTab === "etl"
                  ? "bg-zinc-900 text-emerald-400 border border-zinc-800 shadow-md"
                  : "text-zinc-500 hover:text-zinc-300"
              }`}
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>02 // PANDAS_ETL</span>
            </button>

            <button
              id="tab-ai"
              onClick={() => setActiveTab("ai")}
              className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-lg text-[10px] font-mono font-semibold tracking-wider cursor-pointer transition-all ${
                activeTab === "ai"
                  ? "bg-zinc-900 text-emerald-400 border border-zinc-800 shadow-md"
                  : "text-zinc-500 hover:text-zinc-300"
              }`}
            >
              <Brain className="w-3.5 h-3.5" />
              <span>03 // GEMINI_AI</span>
            </button>
          </div>
        </div>

        {/* CORE WORKSPACE CONTENT */}
        <main className="flex-1 px-6 md:px-10 py-8 bg-zinc-950 overflow-y-auto">
          <AnimatePresence mode="wait">
            {activeTab === "dashboard" && (
              <motion.div
                key="dashboard"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                <RealTimeDashboard
                  activeDataset={activeDataset}
                  streamData={streamData}
                  isStreamingActive={isStreamingActive}
                  totalProcessed={totalProcessed}
                  onToggleStreaming={handleToggleStreaming}
                  onChangeDataset={handleChangeDataset}
                />
              </motion.div>
            )}

            {activeTab === "etl" && (
              <motion.div
                key="etl"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                <ETLPipelineView
                  activeDataset={activeDataset}
                  onPipelineSuccess={handlePipelineSuccess}
                />
              </motion.div>
            )}

            {activeTab === "ai" && (
              <motion.div
                key="ai"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                <AIAssistantPanel
                  activeDataset={activeDataset}
                  streamData={streamData}
                  lastEtlMetrics={lastEtlMetrics}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </main>

        {/* Footer: System Metadata */}
        <footer className="h-14 bg-zinc-950 border-t border-zinc-800 flex items-center justify-between px-6 md:px-10 text-[10px] text-zinc-500 font-mono select-none">
          <div className="flex gap-8">
            <span className="text-zinc-600">LOC: UTC_LIVE_ENGINE</span>
            <span className="hidden sm:inline text-zinc-600">NODE_STATUS: ACTIVE</span>
          </div>
          <div className="text-[10px] font-bold italic tracking-wider text-zinc-400">QUANTUM_ANALYTICS_V4</div>
        </footer>

      </div>
    </div>
  );
}
