import React, { useMemo } from "react";
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, Cell
} from "recharts";
import { Play, Pause, Activity, Cpu, ShoppingBag, Radio, ShieldAlert } from "lucide-react";
import { DatasetType } from "../types";

interface RealTimeDashboardProps {
  activeDataset: DatasetType;
  streamData: any[];
  isStreamingActive: boolean;
  totalProcessed: number;
  onToggleStreaming: (active: boolean) => void;
  onChangeDataset: (type: DatasetType) => void;
}

export default function RealTimeDashboard({
  activeDataset,
  streamData,
  isStreamingActive,
  totalProcessed,
  onToggleStreaming,
  onChangeDataset
}: RealTimeDashboardProps) {

  // Format data for Recharts time-axis or simple ticks
  const chartData = useMemo(() => {
    return streamData.map((d, index) => {
      const timeStr = new Date(d.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      return {
        ...d,
        index,
        timeLabel: timeStr,
        displayVal: activeDataset === "infrastructure" 
          ? d.cpu_usage ?? 0 
          : activeDataset === "ecommerce" 
            ? d.amount ?? 0 
            : d.duration_ms ?? 0
      };
    });
  }, [streamData, activeDataset]);

  // Compute stats for current sliding window
  const stats = useMemo(() => {
    if (!streamData.length) return { average: 0, peak: 0, anomaliesCount: 0 };
    
    let sum = 0;
    let peak = 0;
    let anomaliesCount = 0;

    streamData.forEach(d => {
      if (activeDataset === "infrastructure") {
        const cpu = d.cpu_usage ?? 0;
        sum += cpu;
        if (cpu > peak) peak = cpu;
        if (cpu > 85 || d.status === "warning") anomaliesCount++;
      } else if (activeDataset === "ecommerce") {
        const amt = d.amount ?? 0;
        sum += amt;
        if (amt > peak) peak = amt;
        if (amt > 2000) anomaliesCount++; // Simulated whale transactions
      } else {
        const dur = d.duration_ms ?? 0;
        sum += dur;
        if (dur > peak) peak = dur;
        if (dur > 15000 || d.status === "error") anomaliesCount++;
      }
    });

    return {
      average: parseFloat((sum / streamData.length).toFixed(1)),
      peak: parseFloat(peak.toFixed(1)),
      anomaliesCount
    };
  }, [streamData, activeDataset]);

  // Aggregate categories for the side BarChart
  const aggregatedDistribution = useMemo(() => {
    if (!streamData.length) return [];
    
    const countMap: Record<string, number> = {};
    
    streamData.forEach(d => {
      let key = "";
      if (activeDataset === "infrastructure") {
        key = d.node_id || "unknown";
      } else if (activeDataset === "ecommerce") {
        key = d.category || "General";
      } else {
        key = d.event_type || "other";
      }
      countMap[key] = (countMap[key] || 0) + 1;
    });

    return Object.entries(countMap).map(([name, value]) => ({ name, value }));
  }, [streamData, activeDataset]);

  const yLabel = activeDataset === "infrastructure" 
    ? "CPU Usage (%)" 
    : activeDataset === "ecommerce" 
      ? "Revenue ($)" 
      : "Duration (ms)";

  const COLORS = ["#06b6d4", "#6366f1", "#a855f7", "#ec4899", "#f59e0b", "#10b981"];

  return (
    <div id="real-time-dashboard-view" className="grid grid-cols-1 lg:grid-cols-4 gap-6">
      
      {/* LEFT CONTROL RAIL */}
      <div id="dashboard-controls" className="lg:col-span-1 bg-zinc-900/50 border border-zinc-800 rounded-2xl p-5 flex flex-col justify-between">
        <div>
          <div className="flex items-center gap-2 mb-4">
            <Radio className="w-5 h-5 text-emerald-400 animate-pulse" />
            <h3 className="text-[10px] font-bold tracking-[0.2em] text-zinc-500 uppercase font-mono">Live Pipeline</h3>
          </div>

          <h2 className="text-2xl font-serif italic text-zinc-100 mb-2">Streaming Feeds</h2>
          <p className="text-xs text-zinc-400 mb-6 font-sans leading-relaxed">
            Configure raw data ingestion channels processing simulated high-velocity data points dynamically.
          </p>

          <div className="space-y-3 mb-6">
            <button
              id="select-dataset-infra"
              onClick={() => onChangeDataset("infrastructure")}
              className={`w-full flex items-center justify-between p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                activeDataset === "infrastructure"
                  ? "bg-emerald-950/20 border-emerald-500 text-emerald-300 art-glow-emerald"
                  : "bg-zinc-950/60 border-zinc-800 text-zinc-400 hover:border-zinc-700 hover:text-zinc-300"
              }`}
            >
              <div className="flex items-center gap-3">
                <Cpu className="w-4 h-4 text-emerald-400" />
                <div>
                  <div className="font-semibold text-sm text-zinc-200 font-sans">Server Health</div>
                  <div className="text-[10px] text-zinc-500 font-mono">Node metrics & CPU thermal</div>
                </div>
              </div>
              {activeDataset === "infrastructure" && <div className="w-1.5 h-1.5 rounded-full bg-emerald-400" />}
            </button>

            <button
              id="select-dataset-ecom"
              onClick={() => onChangeDataset("ecommerce")}
              className={`w-full flex items-center justify-between p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                activeDataset === "ecommerce"
                  ? "bg-cyan-950/20 border-cyan-500 text-cyan-300 art-glow-cyan"
                  : "bg-zinc-950/60 border-zinc-800 text-zinc-400 hover:border-zinc-700 hover:text-zinc-300"
              }`}
            >
              <div className="flex items-center gap-3">
                <ShoppingBag className="w-4 h-4 text-cyan-400" />
                <div>
                  <div className="font-semibold text-sm text-zinc-200 font-sans">E-Commerce Revenue</div>
                  <div className="text-[10px] text-zinc-500 font-mono">Global sales transactions</div>
                </div>
              </div>
              {activeDataset === "ecommerce" && <div className="w-1.5 h-1.5 rounded-full bg-cyan-400" />}
            </button>

            <button
              id="select-dataset-saas"
              onClick={() => onChangeDataset("saas_events")}
              className={`w-full flex items-center justify-between p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                activeDataset === "saas_events"
                  ? "bg-indigo-950/20 border-indigo-500 text-indigo-300 art-glow-indigo"
                  : "bg-zinc-950/60 border-zinc-800 text-zinc-400 hover:border-zinc-700 hover:text-zinc-300"
              }`}
            >
              <div className="flex items-center gap-3">
                <Activity className="w-4 h-4 text-indigo-400" />
                <div>
                  <div className="font-semibold text-sm text-zinc-200 font-sans">SaaS Clickstream</div>
                  <div className="text-[10px] text-zinc-500 font-mono">User events & duration latency</div>
                </div>
              </div>
              {activeDataset === "saas_events" && <div className="w-1.5 h-1.5 rounded-full bg-indigo-400" />}
            </button>
          </div>
        </div>

        {/* ACTIVE STREAM STATUS */}
        <div className="pt-4 border-t border-zinc-800">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="text-[10px] uppercase tracking-widest text-zinc-500 font-mono">Ingestion Status</div>
              <div className="flex items-center gap-1.5 mt-1">
                <span className={`w-2 h-2 rounded-full ${isStreamingActive ? "bg-emerald-400 animate-pulse" : "bg-red-500"}`} />
                <span className="text-[11px] font-bold font-mono text-zinc-300">{isStreamingActive ? "ACTIVE_INGEST" : "PAUSED"}</span>
              </div>
            </div>

            <button
              id="toggle-streaming-btn"
              onClick={() => onToggleStreaming(!isStreamingActive)}
              className={`p-2.5 rounded-xl cursor-pointer transition-all ${
                isStreamingActive 
                  ? "bg-zinc-800 text-amber-400 hover:bg-zinc-700" 
                  : "bg-emerald-500 text-zinc-950 hover:bg-emerald-400"
              }`}
            >
              {isStreamingActive ? <Pause className="w-4 h-4 fill-amber-400" /> : <Play className="w-4 h-4 fill-zinc-950" />}
            </button>
          </div>

          <div className="bg-zinc-950 rounded-xl p-3 border border-zinc-800">
            <div className="text-[9px] uppercase tracking-wider text-zinc-500 font-mono">TOTAL DATA POINTS INGESTED</div>
            <div className="text-xl font-mono font-bold text-zinc-100 mt-0.5">
              {totalProcessed.toLocaleString()}
            </div>
            <div className="text-[9px] text-emerald-400 flex items-center gap-1 mt-1 font-mono">
              <span className="w-1 h-1 rounded-full bg-emerald-400 animate-pulse" /> Live window: {streamData.length} pts
            </div>
          </div>
        </div>
      </div>

      {/* CENTER METRIC PLOTS */}
      <div id="metric-plots" className="lg:col-span-3 space-y-6">
        
        {/* RECENT STREAM STAT CARDS */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-zinc-900/40 border border-zinc-800 rounded-2xl p-4">
            <div className="text-[9px] font-semibold text-zinc-500 uppercase tracking-widest font-mono">
              {activeDataset === "infrastructure" ? "Average CPU Load" : activeDataset === "ecommerce" ? "Average Order" : "Avg Action Latency"}
            </div>
            <div className="text-3xl font-bold font-mono text-zinc-100 mt-1">
              {stats.average}
              <span className="text-xs font-normal text-zinc-500 ml-1 font-sans">
                {activeDataset === "infrastructure" ? "%" : activeDataset === "ecommerce" ? "USD" : "ms"}
              </span>
            </div>
            <div className="text-[10px] text-zinc-500 mt-1 font-mono">SLIDING_MEAN_CALC</div>
          </div>

          <div className="bg-zinc-900/40 border border-zinc-800 rounded-2xl p-4">
            <div className="text-[9px] font-semibold text-zinc-500 uppercase tracking-widest font-mono">
              {activeDataset === "infrastructure" ? "Peak CPU Load" : activeDataset === "ecommerce" ? "Peak Transaction" : "Max Event Lag"}
            </div>
            <div className="text-3xl font-bold font-mono text-zinc-100 mt-1">
              {stats.peak}
              <span className="text-xs font-normal text-zinc-500 ml-1 font-sans">
                {activeDataset === "infrastructure" ? "%" : activeDataset === "ecommerce" ? "USD" : "ms"}
              </span>
            </div>
            <div className="text-[10px] text-zinc-500 mt-1 font-mono font-bold text-emerald-500/80">MAX_TELEMETRY_RECORD</div>
          </div>

          <div className="bg-zinc-900/40 border border-zinc-800 rounded-2xl p-4">
            <div className="text-[9px] font-semibold text-zinc-500 uppercase tracking-widest font-mono">
              Warning Alerts / Outliers
            </div>
            <div className="text-3xl font-bold font-mono text-rose-400 mt-1 flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-rose-400 animate-pulse" />
              {stats.anomaliesCount}
            </div>
            <div className="text-[10px] text-zinc-500 mt-1 font-mono">ANOMALOUS_SPIKES_FLAGGED</div>
          </div>
        </div>

        {/* MAIN VISUALIZATION AREA */}
        <div className="bg-zinc-900/40 border border-zinc-800 rounded-2xl p-5">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 gap-3">
            <div>
              <h3 className="text-2xl font-serif italic text-zinc-100">Interactive Ingestion Flow</h3>
              <p className="text-xs text-zinc-400">Dynamic sliding timeline plotting incoming microsecond metrics</p>
            </div>
            <div className="text-[9px] bg-zinc-950 px-2.5 py-1.5 rounded-lg border border-zinc-800 font-mono text-zinc-500">
              Uptime Status: <span className="text-emerald-400 font-bold">99.98%</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            
            {/* AREA CHART */}
            <div className="md:col-span-3 h-72">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="chartColor" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={activeDataset === "infrastructure" ? "#10b981" : activeDataset === "ecommerce" ? "#06b6d4" : "#6366f1"} stopOpacity={0.25}/>
                      <stop offset="95%" stopColor={activeDataset === "infrastructure" ? "#10b981" : activeDataset === "ecommerce" ? "#06b6d4" : "#6366f1"} stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                  <XAxis 
                    dataKey="timeLabel" 
                    stroke="#52525b" 
                    fontSize={9} 
                    tickLine={false} 
                    axisLine={false}
                    minTickGap={30}
                    fontFamily="monospace"
                  />
                  <YAxis 
                    stroke="#52525b" 
                    fontSize={9} 
                    tickLine={false} 
                    axisLine={false}
                    fontFamily="monospace"
                    label={{ value: yLabel, angle: -90, position: 'insideLeft', fill: '#71717a', style: { fontSize: 9, fontWeight: 500 } }}
                  />
                  <Tooltip
                    contentStyle={{ backgroundColor: "#09090b", borderColor: "#27272a", borderRadius: "12px" }}
                    labelClassName="text-zinc-500 text-[9px] font-semibold font-mono"
                    itemStyle={{ color: "#f4f4f5", fontSize: "11px" }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="displayVal" 
                    stroke={activeDataset === "infrastructure" ? "#10b981" : activeDataset === "ecommerce" ? "#06b6d4" : "#6366f1"} 
                    strokeWidth={2}
                    fillOpacity={1} 
                    fill="url(#chartColor)" 
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {/* DISTRIBUTION BAR CHART */}
            <div className="md:col-span-1 h-72 flex flex-col justify-between">
              <div>
                <h4 className="text-xs font-semibold text-zinc-400 mb-1 font-mono uppercase tracking-wider">
                  {activeDataset === "infrastructure" ? "Node Distribution" : activeDataset === "ecommerce" ? "Category Split" : "Event Split"}
                </h4>
                <p className="text-[10px] text-zinc-500 mb-3">Live aggregation breakdown</p>
              </div>

              {aggregatedDistribution.length > 0 ? (
                <div className="h-52 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={aggregatedDistribution} layout="vertical" margin={{ left: -10, right: 10, top: 0, bottom: 0 }}>
                      <XAxis type="number" hide />
                      <YAxis dataKey="name" type="category" stroke="#71717a" fontSize={9} tickLine={false} axisLine={false} width={75} fontFamily="monospace" />
                      <Tooltip
                        contentStyle={{ backgroundColor: "#09090b", borderColor: "#27272a", borderRadius: "8px" }}
                        itemStyle={{ color: "#f4f4f5", fontSize: "10px" }}
                      />
                      <Bar dataKey="value" radius={[0, 4, 4, 0]} barSize={10}>
                        {aggregatedDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              ) : (
                <div className="h-52 flex items-center justify-center text-zinc-500 text-[10px] font-mono">
                  WAITING_FOR_EVENTS...
                </div>
              )}
            </div>

          </div>
        </div>

      </div>

    </div>
  );
}
