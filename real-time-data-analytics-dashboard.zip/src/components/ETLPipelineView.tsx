import React, { useState } from "react";
import { 
  Sliders, Database, Code, Terminal, Play, CheckCircle2, 
  ArrowRight, RefreshCw, AlertCircle, Eye, ChevronRight
} from "lucide-react";
import { DatasetType, ETLConfig, ETLResponse } from "../types";

interface ETLPipelineViewProps {
  activeDataset: DatasetType;
  onPipelineSuccess: (cleanData: any[]) => void;
}

export default function ETLPipelineView({ activeDataset, onPipelineSuccess }: ETLPipelineViewProps) {
  // Config state
  const [config, setConfig] = useState<ETLConfig>({
    imputeMissing: true,
    dropDuplicates: true,
    filterOutliers: true,
    parseDates: true,
    validateConstraints: true
  });

  const [isLoading, setIsLoading] = useState(false);
  const [activeStage, setActiveStage] = useState<number | null>(null);
  const [etlResponse, setEtlResponse] = useState<ETLResponse | null>(null);
  const [showCode, setShowCode] = useState(false);

  const toggleConfig = (key: keyof ETLConfig) => {
    setConfig(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handleRunETL = async () => {
    setIsLoading(true);
    setEtlResponse(null);
    
    try {
      // Step 1: Fetch raw dataset with anomalies from server
      setActiveStage(1);
      await new Promise(resolve => setTimeout(resolve, 800));

      const rawRes = await fetch(`/api/etl/raw-dataset?type=${activeDataset}&size=350`);
      const rawDataPayload = await rawRes.json();
      
      // Step 2: Trigger ETL cleaning execution on server
      setActiveStage(2);
      await new Promise(resolve => setTimeout(resolve, 800));
      
      setActiveStage(3);
      await new Promise(resolve => setTimeout(resolve, 800));

      const runRes = await fetch("/api/etl/run", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: activeDataset,
          rawData: rawDataPayload.data,
          config
        })
      });

      setActiveStage(4);
      await new Promise(resolve => setTimeout(resolve, 600));

      const data: ETLResponse = await runRes.json();
      setEtlResponse(data);
      onPipelineSuccess(data.transformedData); // Feed the newly cleaned dataset into the charts!

    } catch (err) {
      console.error("ETL execution failed", err);
    } finally {
      setIsLoading(false);
      setActiveStage(null);
    }
  };

  // Human names for datasets
  const datasetName = activeDataset === "infrastructure" 
    ? "Server Telemetry" 
    : activeDataset === "ecommerce" 
      ? "E-Commerce Transactions" 
      : "SaaS Activity Log";

  return (
    <div id="etl-pipeline-view" className="grid grid-cols-1 xl:grid-cols-12 gap-6 bg-zinc-950">
      
      {/* COLUMN 1: ETL CONTROLS & PIPELINE STAGES (xl:col-span-5) */}
      <div className="xl:col-span-5 space-y-6">
        
        {/* PIPELINE CONTROLS CONFIG */}
        <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <Sliders className="w-5 h-5 text-emerald-400" />
            <h3 className="text-[10px] font-bold tracking-[0.2em] text-zinc-500 uppercase font-mono">ETL Configuration</h3>
          </div>

          <h2 className="text-2xl font-serif italic text-zinc-100 mb-2">Configure Cleaning Job</h2>
          <p className="text-xs text-zinc-400 mb-5 leading-relaxed">
            Select automated processing steps to transform and cleanse anomalous, duplicate, or missing raw datasets.
          </p>

          <div className="space-y-3.5 mb-6">
            <label className="flex items-start justify-between p-3 rounded-xl bg-zinc-950 border border-zinc-850 hover:border-zinc-700 cursor-pointer transition-all">
              <div className="flex items-start gap-3">
                <input
                  type="checkbox"
                  checked={config.dropDuplicates}
                  onChange={() => toggleConfig("dropDuplicates")}
                  className="mt-1 accent-emerald-500 rounded cursor-pointer"
                />
                <div>
                  <span className="font-semibold text-sm text-zinc-200">De-duplicate Rows</span>
                  <p className="text-[10px] text-zinc-500 mt-0.5">Removes exact clone records (pandas.drop_duplicates)</p>
                </div>
              </div>
              <span className="text-[9px] font-mono bg-zinc-900 text-zinc-400 px-1.5 py-0.5 rounded tracking-wider">CLEAN</span>
            </label>

            <label className="flex items-start justify-between p-3 rounded-xl bg-zinc-950 border border-zinc-850 hover:border-zinc-700 cursor-pointer transition-all">
              <div className="flex items-start gap-3">
                <input
                  type="checkbox"
                  checked={config.imputeMissing}
                  onChange={() => toggleConfig("imputeMissing")}
                  className="mt-1 accent-emerald-500 rounded cursor-pointer"
                />
                <div>
                  <span className="font-semibold text-sm text-zinc-200">Mean / Mode Imputation</span>
                  <p className="text-[10px] text-zinc-500 mt-0.5">Imputes null metrics with sliding median or default strings</p>
                </div>
              </div>
              <span className="text-[9px] font-mono bg-zinc-900 text-zinc-400 px-1.5 py-0.5 rounded tracking-wider">IMPUTE</span>
            </label>

            <label className="flex items-start justify-between p-3 rounded-xl bg-zinc-950 border border-zinc-850 hover:border-zinc-700 cursor-pointer transition-all">
              <div className="flex items-start gap-3">
                <input
                  type="checkbox"
                  checked={config.filterOutliers}
                  onChange={() => toggleConfig("filterOutliers")}
                  className="mt-1 accent-emerald-500 rounded cursor-pointer"
                />
                <div>
                  <span className="font-semibold text-sm text-zinc-200">Statistical Outlier Rejection</span>
                  <p className="text-[10px] text-zinc-500 mt-0.5">Filters out extreme telemetry spikes beyond z-score limits</p>
                </div>
              </div>
              <span className="text-[9px] font-mono bg-zinc-900 text-zinc-400 px-1.5 py-0.5 rounded tracking-wider">FILTER</span>
            </label>

            <label className="flex items-start justify-between p-3 rounded-xl bg-zinc-950 border border-zinc-850 hover:border-zinc-700 cursor-pointer transition-all">
              <div className="flex items-start gap-3">
                <input
                  type="checkbox"
                  checked={config.parseDates}
                  onChange={() => toggleConfig("parseDates")}
                  className="mt-1 accent-emerald-500 rounded cursor-pointer"
                />
                <div>
                  <span className="font-semibold text-sm text-zinc-200">DateTime Structuring</span>
                  <p className="text-[10px] text-zinc-500 mt-0.5">Parses Unix timestamp epochs into split date parameters</p>
                </div>
              </div>
              <span className="text-[9px] font-mono bg-zinc-900 text-zinc-400 px-1.5 py-0.5 rounded tracking-wider">TRANSFORM</span>
            </label>

            <label className="flex items-start justify-between p-3 rounded-xl bg-zinc-950 border border-zinc-850 hover:border-zinc-700 cursor-pointer transition-all">
              <div className="flex items-start gap-3">
                <input
                  type="checkbox"
                  checked={config.validateConstraints}
                  onChange={() => toggleConfig("validateConstraints")}
                  className="mt-1 accent-emerald-500 rounded cursor-pointer"
                />
                <div>
                  <span className="font-semibold text-sm text-zinc-200">Schema Bounds Check</span>
                  <p className="text-[10px] text-zinc-500 mt-0.5">Validates numeric columns fit structural database constraints</p>
                </div>
              </div>
              <span className="text-[9px] font-mono bg-zinc-900 text-zinc-400 px-1.5 py-0.5 rounded tracking-wider">VALIDATE</span>
            </label>
          </div>

          <button
            id="run-etl-btn"
            onClick={handleRunETL}
            disabled={isLoading}
            className="w-full bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold py-3.5 px-4 rounded-xl flex items-center justify-center gap-2 cursor-pointer disabled:opacity-55 disabled:cursor-not-allowed transition-all art-glow-emerald"
          >
            {isLoading ? (
              <>
                <RefreshCw className="w-5 h-5 animate-spin" />
                <span className="font-mono text-xs tracking-wider">RUNNING_AUTOMATED_ETL_PIPELINE...</span>
              </>
            ) : (
              <>
                <Play className="w-5 h-5 fill-zinc-950" />
                <span>Execute ETL Pipeline on {datasetName}</span>
              </>
            )}
          </button>
        </div>

        {/* PIPELINE STAGES GRAPHICS */}
        <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-5">
          <h3 className="text-[10px] font-bold tracking-[0.2em] text-zinc-500 uppercase font-mono mb-4">Pipeline Execution Stages</h3>
          
          <div className="space-y-4">
            <div className={`flex items-center gap-4 p-3 rounded-xl border transition-all ${
              activeStage === 1 ? "bg-emerald-950/20 border-emerald-500 text-emerald-300 scale-[1.02] art-glow-emerald" : "bg-zinc-950/40 border-zinc-800 text-zinc-500"
            }`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs font-mono ${
                activeStage === 1 ? "bg-emerald-400 text-zinc-950" : "bg-zinc-900 text-zinc-400"
              }`}>1</div>
              <div className="flex-1">
                <div className="text-xs font-bold text-zinc-200">Extract Source (RAW Ingest)</div>
                <div className="text-[10px] text-zinc-500">Loading historical anomalous streams</div>
              </div>
              {activeStage === 1 && <span className="text-[10px] font-semibold text-emerald-400 animate-pulse font-mono">EXTRACTING...</span>}
            </div>

            <div className={`flex items-center gap-4 p-3 rounded-xl border transition-all ${
              activeStage === 2 ? "bg-emerald-950/20 border-emerald-500 text-emerald-300 scale-[1.02] art-glow-emerald" : "bg-zinc-950/40 border-zinc-800 text-zinc-500"
            }`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs font-mono ${
                activeStage === 2 ? "bg-emerald-400 text-zinc-950" : "bg-zinc-900 text-zinc-400"
              }`}>2</div>
              <div className="flex-1">
                <div className="text-xs font-bold text-zinc-200">Cleanse & Impute</div>
                <div className="text-[10px] text-zinc-500">De-duplicating and filling null indices</div>
              </div>
              {activeStage === 2 && <span className="text-[10px] font-semibold text-emerald-400 animate-pulse font-mono">CLEANING...</span>}
            </div>

            <div className={`flex items-center gap-4 p-3 rounded-xl border transition-all ${
              activeStage === 3 ? "bg-emerald-950/20 border-emerald-500 text-emerald-300 scale-[1.02] art-glow-emerald" : "bg-zinc-950/40 border-zinc-800 text-zinc-500"
            }`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs font-mono ${
                activeStage === 3 ? "bg-emerald-400 text-zinc-950" : "bg-zinc-900 text-zinc-400"
              }`}>3</div>
              <div className="flex-1">
                <div className="text-xs font-bold text-zinc-200">Transform Schema</div>
                <div className="text-[10px] text-zinc-500">Time-axis parsing and feature engineering</div>
              </div>
              {activeStage === 3 && <span className="text-[10px] font-semibold text-emerald-400 animate-pulse font-mono">TRANSFORMING...</span>}
            </div>

            <div className={`flex items-center gap-4 p-3 rounded-xl border transition-all ${
              activeStage === 4 ? "bg-emerald-950/20 border-emerald-500 text-emerald-300 scale-[1.02] art-glow-emerald" : "bg-zinc-950/40 border-zinc-800 text-zinc-500"
            }`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs font-mono ${
                activeStage === 4 ? "bg-emerald-400 text-zinc-950" : "bg-zinc-900 text-zinc-400"
              }`}>4</div>
              <div className="flex-1">
                <div className="text-xs font-bold text-zinc-200">Validate Quality Constraints</div>
                <div className="text-[10px] text-zinc-500">Great Expectations data validation check</div>
              </div>
              {activeStage === 4 && <span className="text-[10px] font-semibold text-emerald-400 animate-pulse font-mono">VALIDATING...</span>}
            </div>
          </div>
        </div>

      </div>

      {/* COLUMN 2: EXECUTION LOGS & CODE (xl:col-span-7) */}
      <div className="xl:col-span-7 space-y-6">
        
        {/* PIPELINE OUTPUT SUMMARY CARD */}
        {etlResponse && (
          <div className="bg-zinc-900/50 border border-emerald-500/30 rounded-2xl p-5 relative overflow-hidden art-glow-emerald">
            <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 rounded-full blur-2xl" />
            <h3 className="text-sm font-semibold tracking-wider text-emerald-400 uppercase mb-3 flex items-center gap-2 font-mono">
              <CheckCircle2 className="w-4.5 h-4.5 text-emerald-400" /> Pipeline Completed Successfully
            </h3>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
              <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800">
                <span className="text-[9px] text-zinc-500 block uppercase font-mono tracking-wider">Raw Rows</span>
                <span className="text-lg font-bold font-mono text-zinc-100">{etlResponse.metrics.initialRows}</span>
              </div>
              <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800">
                <span className="text-[9px] text-zinc-500 block uppercase font-mono tracking-wider">Cleaned Rows</span>
                <span className="text-lg font-bold font-mono text-emerald-400">{etlResponse.metrics.cleanedRows}</span>
              </div>
              <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800">
                <span className="text-[9px] text-zinc-500 block uppercase font-mono tracking-wider">Anomalies Filtered</span>
                <span className="text-lg font-bold font-mono text-amber-400">
                  {etlResponse.metrics.duplicatesRemoved + etlResponse.metrics.nullsRemoved + etlResponse.metrics.outliersFiltered}
                </span>
              </div>
              <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800">
                <span className="text-[9px] text-zinc-500 block uppercase font-mono tracking-wider">Proc Time</span>
                <span className="text-lg font-bold font-mono text-zinc-100">{etlResponse.metrics.processingTimeMs}ms</span>
              </div>
            </div>

            <div className="flex gap-4 mt-4 font-mono text-[10px]">
              <div className="text-zinc-300">
                ✔️ Duplicates: <span className="font-bold text-zinc-100">{etlResponse.metrics.duplicatesRemoved}</span>
              </div>
              <div className="text-zinc-300">
                ✔️ Imputed Cells: <span className="font-bold text-zinc-100">{etlResponse.metrics.nullsRemoved}</span>
              </div>
              <div className="text-zinc-300">
                ✔️ Outliers Removed: <span className="font-bold text-zinc-100">{etlResponse.metrics.outliersFiltered}</span>
              </div>
            </div>
          </div>
        )}

        {/* WORKSPACE PREVIEW: TERMINAL LOGS OR PYTHON CODE */}
        <div className="bg-zinc-950 border border-zinc-800 rounded-2xl overflow-hidden flex flex-col h-[520px]">
          
          {/* TAB HEADERS */}
          <div className="bg-zinc-900/40 border-b border-zinc-800 flex justify-between items-center px-4 py-2">
            <div className="flex gap-2">
              <button
                onClick={() => setShowCode(false)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-mono font-medium cursor-pointer transition-all ${
                  !showCode ? "bg-zinc-900 text-zinc-100 border border-zinc-850" : "text-zinc-500 hover:text-zinc-300"
                }`}
              >
                <Terminal className="w-3.5 h-3.5" />
                <span>Pandas stdout</span>
              </button>
              <button
                onClick={() => setShowCode(true)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-mono font-medium cursor-pointer transition-all ${
                  showCode ? "bg-zinc-900 text-zinc-100 border border-zinc-850" : "text-zinc-500 hover:text-zinc-300"
                }`}
              >
                <Code className="w-3.5 h-3.5" />
                <span>Python & Pandas Snippet</span>
              </button>
            </div>
            <div className="flex gap-1.5">
              <span className="w-2 h-2 rounded-full bg-red-500/60" />
              <span className="w-2 h-2 rounded-full bg-amber-500/60" />
              <span className="w-2 h-2 rounded-full bg-emerald-500/60" />
            </div>
          </div>

          {/* TAB CONTENT: TERMINAL LOGS */}
          {!showCode ? (
            <div className="p-4 flex-1 font-mono text-[11px] overflow-y-auto space-y-1 bg-zinc-950 text-zinc-300 leading-relaxed scrollbar-thin">
              <span className="text-zinc-600 block border-b border-zinc-900 pb-2 mb-3"># Python ETL stdout (Log Buffer)</span>
              
              {isLoading ? (
                <div className="flex flex-col items-center justify-center h-full gap-3 text-zinc-500">
                  <RefreshCw className="w-6 h-6 animate-spin text-emerald-400" />
                  <span className="text-xs">Processing dataset transformations on server...</span>
                </div>
              ) : etlResponse ? (
                etlResponse.logs.map((log, index) => {
                  let color = "text-zinc-300";
                  if (log.startsWith("[ETL START]")) color = "text-emerald-400 font-semibold";
                  else if (log.startsWith("[ETL COMPLETE]")) color = "text-emerald-400 font-bold border-t border-zinc-900/60 pt-2 mt-2";
                  else if (log.includes("Eliminated")) color = "text-cyan-300";
                  else if (log.includes("imputed")) color = "text-indigo-300";
                  else if (log.includes("Filtered")) color = "text-amber-300";
                  
                  return (
                    <div key={index} className={`py-0.5 ${color}`}>
                      <span className="text-zinc-600 select-none mr-2">[{new Date().toLocaleTimeString()}]</span>
                      {log}
                    </div>
                  );
                })
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-zinc-500 text-center p-6">
                  <AlertCircle className="w-8 h-8 text-zinc-700 mb-2" />
                  <span>No ETL job executed yet. Configure parameters and click "Execute" to clean historical stream data.</span>
                </div>
              )}
            </div>
          ) : (
            // TAB CONTENT: PYTHON CODE
            <div className="p-4 flex-1 font-mono text-[11px] overflow-y-auto bg-zinc-950 text-emerald-400 leading-relaxed scrollbar-thin">
              <span className="text-zinc-600 block border-b border-zinc-900 pb-2 mb-3"># Automatically generated python Pandas pipeline script</span>
              
              {etlResponse ? (
                <pre className="text-emerald-300 whitespace-pre-wrap">{etlResponse.pythonCode}</pre>
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-zinc-500 text-center p-6">
                  <Code className="w-8 h-8 text-zinc-700 mb-2" />
                  <span>Python pandas script will be compiled according to your selected ETL settings.</span>
                </div>
              )}
            </div>
          )}
        </div>

      </div>

      {/* TABLE VIEW OF CLEANED SAMPLES */}
      {etlResponse && etlResponse.transformedData.length > 0 && (
        <div className="xl:col-span-12 bg-zinc-900/50 border border-zinc-800 rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <Eye className="w-5 h-5 text-emerald-400" />
            <h3 className="text-sm font-semibold text-zinc-200">Cleaned Dataframe Explorer (Samples)</h3>
          </div>
          <div className="overflow-x-auto rounded-xl border border-zinc-800 bg-zinc-950">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-zinc-800/80 bg-zinc-900/40 text-zinc-400 font-semibold font-mono tracking-wider">
                  <th className="p-3">Index</th>
                  {Object.keys(etlResponse.transformedData[0]).slice(0, 6).map((key) => (
                    <th key={key} className="p-3">{key}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-900 font-mono text-zinc-300">
                {etlResponse.transformedData.slice(0, 5).map((row, idx) => (
                  <tr key={idx} className="hover:bg-zinc-900/30">
                    <td className="p-3 text-zinc-600">{idx + 1}</td>
                    {Object.values(row).slice(0, 6).map((val: any, cellIdx) => (
                      <td key={cellIdx} className="p-3 truncate max-w-[150px]">
                        {val === null || val === undefined ? (
                          <span className="text-rose-400 font-semibold">NaN</span>
                        ) : typeof val === "number" ? (
                          val.toFixed(2)
                        ) : (
                          String(val)
                        )}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="text-[10px] text-zinc-500 mt-2 text-right font-mono">
            Showing top 5 of {etlResponse.transformedData.length} records.
          </div>
        </div>
      )}

    </div>
  );
}
