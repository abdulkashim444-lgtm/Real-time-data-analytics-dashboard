import React, { useState, useMemo } from "react";
import ReactMarkdown from "react-markdown";
import { Sparkles, Send, Brain, AlertTriangle, ShieldAlert, Cpu, TrendingUp, Lightbulb } from "lucide-react";
import { DatasetType, ETLMetrics } from "../types";

interface AIAssistantPanelProps {
  activeDataset: DatasetType;
  streamData: any[];
  lastEtlMetrics: ETLMetrics | null;
}

export default function AIAssistantPanel({ activeDataset, streamData, lastEtlMetrics }: AIAssistantPanelProps) {
  const [inputText, setInputText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [aiResponse, setAiResponse] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Compute live summaries to give Gemini rich context
  const summaryStats = useMemo(() => {
    if (!streamData.length) return { message: "No stream data currently active." };

    if (activeDataset === "infrastructure") {
      let cpuSum = 0, tempSum = 0;
      let maxCpu = 0, maxTemp = 0;
      let warnings = 0;

      streamData.forEach(d => {
        const cpu = d.cpu_usage ?? 0;
        const t = d.temperature_c ?? 0;
        cpuSum += cpu;
        tempSum += t;
        if (cpu > maxCpu) maxCpu = cpu;
        if (t > maxTemp) maxTemp = t;
        if (d.status === "warning") warnings++;
      });

      return {
        sampleSize: streamData.length,
        averageCpu: (cpuSum / streamData.length).toFixed(1) + "%",
        peakCpu: maxCpu + "%",
        averageTemperature: (tempSum / streamData.length).toFixed(1) + "C",
        peakTemperature: maxTemp + "C",
        nodeWarningRate: ((warnings / streamData.length) * 100).toFixed(1) + "%",
        activeETLApplied: !!lastEtlMetrics
      };
    } else if (activeDataset === "ecommerce") {
      let revenueSum = 0;
      let maxAmt = 0;
      const catCount: Record<string, number> = {};

      streamData.forEach(d => {
        const amt = d.amount ?? 0;
        revenueSum += amt;
        if (amt > maxAmt) maxAmt = amt;
        if (d.category) {
          catCount[d.category] = (catCount[d.category] || 0) + 1;
        }
      });

      return {
        sampleSize: streamData.length,
        cumulativeRevenue: "$" + revenueSum.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }),
        averageTransaction: "$" + (revenueSum / streamData.length).toFixed(2),
        peakTransaction: "$" + maxAmt.toFixed(2),
        categoryCounts: catCount,
        activeETLApplied: !!lastEtlMetrics
      };
    } else {
      let durSum = 0;
      let maxDur = 0;
      let errorCount = 0;

      streamData.forEach(d => {
        const dur = d.duration_ms ?? 0;
        durSum += dur;
        if (dur > maxDur) maxDur = dur;
        if (d.status === "error") errorCount++;
      });

      return {
        sampleSize: streamData.length,
        averageDurationMs: (durSum / streamData.length).toFixed(0) + "ms",
        maxDurationMs: maxDur + "ms",
        errorCount,
        errorRate: ((errorCount / streamData.length) * 100).toFixed(1) + "%",
        activeETLApplied: !!lastEtlMetrics
      };
    }
  }, [streamData, activeDataset, lastEtlMetrics]);

  const handlePresetTrigger = async (queryType: "anomalies" | "forecast" | "recommendations" | "custom", customPrompt = "") => {
    setIsLoading(true);
    setAiResponse(null);
    setErrorMessage(null);

    try {
      const res = await fetch("/api/gemini/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          datasetType: activeDataset,
          summaryStats,
          queryType,
          userPrompt: customPrompt
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to fetch response.");
      }
      setAiResponse(data.text);
    } catch (err: any) {
      console.error("AI Analysis failed:", err);
      setErrorMessage(err.message || "An error occurred during pipeline telemetry analysis.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    handlePresetTrigger("custom", inputText);
    setInputText("");
  };

  return (
    <div id="ai-assistant-panel" className="grid grid-cols-1 lg:grid-cols-12 gap-6 bg-zinc-950">
      
      {/* PRESETS SIDEBAR (lg:col-span-4) */}
      <div className="lg:col-span-4 space-y-6">
        <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <Brain className="w-5 h-5 text-cyan-400" />
            <h3 className="text-[10px] font-bold tracking-[0.2em] text-zinc-500 uppercase font-mono">AI Data Scientist</h3>
          </div>

          <h2 className="text-2xl font-serif italic text-zinc-100 mb-2">Gemini Analyst</h2>
          <p className="text-xs text-zinc-400 mb-6 leading-relaxed">
            Leverage Google Gemini model to conduct advanced statistical reasoning, detect performance bugs, and forecast telemetry.
          </p>

          <div className="space-y-3">
            <button
              id="ai-preset-anomalies"
              onClick={() => handlePresetTrigger("anomalies")}
              disabled={isLoading}
              className="w-full flex items-center gap-3 p-3 text-left rounded-xl border border-zinc-850 bg-zinc-950/60 hover:bg-zinc-950 hover:border-zinc-700 text-zinc-300 hover:text-white transition-all disabled:opacity-50 cursor-pointer"
            >
              <ShieldAlert className="w-4.5 h-4.5 text-rose-400 flex-shrink-0" />
              <div>
                <div className="text-xs font-semibold font-sans">Audit Stream Anomalies</div>
                <div className="text-[10px] text-zinc-500 mt-0.5">Detect system warnings and outline outlier filters</div>
              </div>
            </button>

            <button
              id="ai-preset-forecast"
              onClick={() => handlePresetTrigger("forecast")}
              disabled={isLoading}
              className="w-full flex items-center gap-3 p-3 text-left rounded-xl border border-zinc-850 bg-zinc-950/60 hover:bg-zinc-950 hover:border-zinc-700 text-zinc-300 hover:text-white transition-all disabled:opacity-50 cursor-pointer"
            >
              <TrendingUp className="w-4.5 h-4.5 text-cyan-400 flex-shrink-0" />
              <div>
                <div className="text-xs font-semibold font-sans">Forecast Operational Load</div>
                <div className="text-[10px] text-zinc-500 mt-0.5">Project spikes and capacity constraints for next 24h</div>
              </div>
            </button>

            <button
              id="ai-preset-recs"
              onClick={() => handlePresetTrigger("recommendations")}
              disabled={isLoading}
              className="w-full flex items-center gap-3 p-3 text-left rounded-xl border border-zinc-850 bg-zinc-950/60 hover:bg-zinc-950 hover:border-zinc-700 text-zinc-300 hover:text-white transition-all disabled:opacity-50 cursor-pointer"
            >
              <Lightbulb className="w-4.5 h-4.5 text-amber-400 flex-shrink-0" />
              <div>
                <div className="text-xs font-semibold font-sans">Get Strategic Optimizations</div>
                <div className="text-[10px] text-zinc-500 mt-0.5">Actions to resolve metrics degradation 95% faster</div>
              </div>
            </button>
          </div>
        </div>

        {/* ACTIVE DATASET META CARD */}
        <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-4">
          <div className="text-[9px] font-bold text-zinc-500 uppercase tracking-widest font-mono mb-2">Active Metadata Sent to AI</div>
          <pre className="text-[10px] text-cyan-400 font-mono bg-zinc-950 p-3 rounded-xl border border-zinc-800/80 overflow-x-auto max-h-52 scrollbar-thin">
            {JSON.stringify(summaryStats, null, 2)}
          </pre>
        </div>
      </div>

      {/* CHAT/REPORT DISPLAY (lg:col-span-8) */}
      <div className="lg:col-span-8 flex flex-col justify-between bg-zinc-900/50 border border-zinc-800 rounded-2xl overflow-hidden h-[480px]">
        
        {/* VIEW WINDOW */}
        <div className="flex-1 p-5 overflow-y-auto space-y-4 scrollbar-thin">
          
          {isLoading ? (
            <div className="flex flex-col items-center justify-center h-full gap-4 text-center">
              <Sparkles className="w-10 h-10 text-cyan-400 animate-spin" />
              <div>
                <h4 className="text-sm font-semibold text-zinc-100 animate-pulse font-serif italic">Consulting Gemini Data Scientist...</h4>
                <p className="text-xs text-zinc-400 mt-1 max-w-sm mx-auto">Parsing stream matrices, fitting models, and generating strategic actions.</p>
              </div>
            </div>
          ) : errorMessage ? (
            <div className="flex flex-col items-center justify-center h-full text-center p-6 bg-rose-950/10 border border-rose-500/20 rounded-xl">
              <ShieldAlert className="w-10 h-10 text-rose-400 mb-2" />
              <h4 className="text-sm font-bold text-rose-200">Analysis Pipeline Interrupted</h4>
              <p className="text-xs text-rose-400 mt-1 max-w-md">{errorMessage}</p>
            </div>
          ) : aiResponse ? (
            <div className="space-y-4">
              <div className="flex items-center gap-2 pb-2 border-b border-zinc-800">
                <Sparkles className="w-4.5 h-4.5 text-cyan-400" />
                <h4 className="text-xs font-bold text-zinc-400 uppercase tracking-widest font-mono">AI Analytical Report</h4>
              </div>
              <div className="markdown-body prose prose-invert text-xs text-zinc-300 leading-relaxed max-w-none space-y-3">
                <ReactMarkdown>{aiResponse}</ReactMarkdown>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-center text-zinc-500">
              <Brain className="w-12 h-12 text-zinc-700 mb-3" />
              <h4 className="text-sm font-semibold text-zinc-400 font-serif italic">Strategic Decision Engine Ready</h4>
              <p className="text-xs text-zinc-500 mt-1 max-w-sm">
                Select one of the preset data-auditing tools on the left, or input a custom prompt below to ask questions about your active metrics.
              </p>
            </div>
          )}

        </div>

        {/* PROMPT FORM */}
        <form onSubmit={handleFormSubmit} className="bg-zinc-950 border-t border-zinc-850 p-3 flex gap-2">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            disabled={isLoading}
            placeholder={`Ask Gemini about the active ${activeDataset} stream... (e.g. "Identify CPU bottlenecks")`}
            className="flex-1 bg-zinc-900/50 border border-zinc-800 focus:border-zinc-700 outline-none rounded-xl px-4 py-2.5 text-xs text-zinc-100 placeholder-zinc-500 disabled:opacity-50"
          />
          <button
            type="submit"
            disabled={isLoading || !inputText.trim()}
            className="bg-cyan-500 hover:bg-cyan-400 disabled:opacity-40 text-zinc-950 p-2.5 rounded-xl cursor-pointer disabled:cursor-not-allowed transition-all art-glow-cyan"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

      </div>

    </div>
  );
}
