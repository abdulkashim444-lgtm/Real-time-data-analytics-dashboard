export type DatasetType = "ecommerce" | "infrastructure" | "saas_events";

export interface ETLConfig {
  imputeMissing: boolean;
  dropDuplicates: boolean;
  filterOutliers: boolean;
  parseDates: boolean;
  validateConstraints: boolean;
}

export interface ETLMetrics {
  initialRows: number;
  cleanedRows: number;
  nullsRemoved: number;
  duplicatesRemoved: number;
  outliersFiltered: number;
  invalidTypesCoerced: number;
  processingTimeMs: number;
}

export interface ETLResponse {
  type: DatasetType;
  metrics: ETLMetrics;
  logs: string[];
  pythonCode: string;
  transformedData: any[];
}

export interface StreamStatus {
  isStreamingActive: boolean;
  streamingDatasetType: DatasetType;
  totalDataPointsProcessed: number;
  streamSize: number;
}
